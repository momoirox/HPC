#include <iostream>

using std::cout;
using std::endl;


void hello_world() {
    cout << "Hello world!" << endl;
}


int main() {

    hello_world();

    return 0;
}