#include <stdio.h>


void hello_world() {
    printf("Hello world!");
}


int main() {

    hello_world();

    return 0;
}
